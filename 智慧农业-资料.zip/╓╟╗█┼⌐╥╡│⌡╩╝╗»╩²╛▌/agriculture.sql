/*
 Navicat Premium Data Transfer

 Source Server         : 172.16.5.240(test)
 Source Server Type    : MySQL
 Source Server Version : 50717
 Source Host           : 172.16.5.240:3306
 Source Schema         : agriculture

 Target Server Type    : MySQL
 Target Server Version : 50717
 File Encoding         : 65001

 Date: 21/08/2019 16:53:28
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for qrtz_blob_triggers
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_blob_triggers`;
CREATE TABLE `qrtz_blob_triggers`  (
  `sched_name` varchar(120) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `trigger_name` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `trigger_group` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `blob_data` blob NULL,
  PRIMARY KEY (`sched_name`, `trigger_name`, `trigger_group`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = 'blob触发表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for qrtz_calendars
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_calendars`;
CREATE TABLE `qrtz_calendars`  (
  `sched_name` varchar(120) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `calendar_name` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `calendar` blob NOT NULL,
  PRIMARY KEY (`sched_name`, `calendar_name`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '日历表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for qrtz_cron_triggers
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_cron_triggers`;
CREATE TABLE `qrtz_cron_triggers`  (
  `sched_name` varchar(120) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `trigger_name` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `trigger_group` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `cron_expression` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `time_zone_id` varchar(80) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`sched_name`, `trigger_name`, `trigger_group`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = 'cron触发表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for qrtz_fired_triggers
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_fired_triggers`;
CREATE TABLE `qrtz_fired_triggers`  (
  `sched_name` varchar(120) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `entry_id` varchar(95) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `trigger_name` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `trigger_group` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `instance_name` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `fired_time` bigint(13) NOT NULL,
  `sched_time` bigint(13) NOT NULL,
  `priority` int(11) NOT NULL,
  `state` varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `job_name` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `job_group` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `is_nonconcurrent` varchar(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `requests_recovery` varchar(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`sched_name`, `entry_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = 'fired触发表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for qrtz_job_details
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_job_details`;
CREATE TABLE `qrtz_job_details`  (
  `sched_name` varchar(120) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `job_name` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `job_group` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `description` varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `job_class_name` varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `is_durable` varchar(1) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `is_nonconcurrent` varchar(1) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `is_update_data` varchar(1) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `requests_recovery` varchar(1) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `job_data` blob NULL,
  PRIMARY KEY (`sched_name`, `job_name`, `job_group`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '任务详情表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for qrtz_locks
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_locks`;
CREATE TABLE `qrtz_locks`  (
  `sched_name` varchar(120) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `lock_name` varchar(40) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`sched_name`, `lock_name`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '定时任务锁定表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for qrtz_paused_trigger_grps
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_paused_trigger_grps`;
CREATE TABLE `qrtz_paused_trigger_grps`  (
  `sched_name` varchar(120) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `trigger_group` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`sched_name`, `trigger_group`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '定时任务暂停表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for qrtz_scheduler_state
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_scheduler_state`;
CREATE TABLE `qrtz_scheduler_state`  (
  `sched_name` varchar(120) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `instance_name` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `last_checkin_time` bigint(13) NOT NULL,
  `checkin_interval` bigint(13) NOT NULL,
  PRIMARY KEY (`sched_name`, `instance_name`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '定时任务状态表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for qrtz_simple_triggers
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_simple_triggers`;
CREATE TABLE `qrtz_simple_triggers`  (
  `sched_name` varchar(120) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `trigger_name` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `trigger_group` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `repeat_count` bigint(7) NOT NULL,
  `repeat_interval` bigint(12) NOT NULL,
  `times_triggered` bigint(10) NOT NULL,
  PRIMARY KEY (`sched_name`, `trigger_name`, `trigger_group`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '基础定时任务表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for qrtz_simprop_triggers
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_simprop_triggers`;
CREATE TABLE `qrtz_simprop_triggers`  (
  `sched_name` varchar(120) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `trigger_name` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `trigger_group` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `str_prop_1` varchar(512) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `str_prop_2` varchar(512) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `str_prop_3` varchar(512) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `int_prop_1` int(11) NULL DEFAULT NULL,
  `int_prop_2` int(11) NULL DEFAULT NULL,
  `long_prop_1` bigint(20) NULL DEFAULT NULL,
  `long_prop_2` bigint(20) NULL DEFAULT NULL,
  `dec_prop_1` decimal(13, 4) NULL DEFAULT NULL,
  `dec_prop_2` decimal(13, 4) NULL DEFAULT NULL,
  `bool_prop_1` varchar(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `bool_prop_2` varchar(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`sched_name`, `trigger_name`, `trigger_group`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '配置任务表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for qrtz_triggers
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_triggers`;
CREATE TABLE `qrtz_triggers`  (
  `sched_name` varchar(120) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `trigger_name` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `trigger_group` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `job_name` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `job_group` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `description` varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `next_fire_time` bigint(13) NULL DEFAULT NULL,
  `prev_fire_time` bigint(13) NULL DEFAULT NULL,
  `priority` int(11) NULL DEFAULT NULL,
  `trigger_state` varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `trigger_type` varchar(8) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `start_time` bigint(13) NOT NULL,
  `end_time` bigint(13) NULL DEFAULT NULL,
  `calendar_name` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `misfire_instr` smallint(2) NULL DEFAULT NULL,
  `job_data` blob NULL,
  PRIMARY KEY (`sched_name`, `trigger_name`, `trigger_group`) USING BTREE,
  INDEX `sched_name`(`sched_name`, `job_name`, `job_group`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = 'job 基础表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for sys_config
-- ----------------------------
DROP TABLE IF EXISTS `sys_config`;
CREATE TABLE `sys_config`  (
  `config_id` int(5) NOT NULL AUTO_INCREMENT COMMENT '参数主键',
  `config_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '参数名称',
  `config_key` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '参数键名',
  `config_value` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '参数键值',
  `config_type` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT 'N' COMMENT '系统内置（Y是 N否）',
  `create_by` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`config_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '参数配置表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for sys_dept
-- ----------------------------
DROP TABLE IF EXISTS `sys_dept`;
CREATE TABLE `sys_dept`  (
  `dept_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '部门id',
  `parent_id` int(11) NULL DEFAULT 0 COMMENT '父部门id',
  `ancestors` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '祖级列表',
  `dept_name` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '部门名称',
  `order_num` int(4) NULL DEFAULT 0 COMMENT '显示顺序',
  `leader` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '负责人',
  `phone` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '联系电话',
  `email` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '邮箱',
  `status` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '0' COMMENT '部门状态（0正常 1停用）',
  `del_flag` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  `create_by` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`dept_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 110 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '部门表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for sys_dict_data
-- ----------------------------
DROP TABLE IF EXISTS `sys_dict_data`;
CREATE TABLE `sys_dict_data`  (
  `dict_code` bigint(11) NOT NULL AUTO_INCREMENT COMMENT '字典编码',
  `dict_sort` int(4) NULL DEFAULT 0 COMMENT '字典排序',
  `dict_label` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '字典标签',
  `dict_value` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '字典键值',
  `dict_type` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '字典类型',
  `css_class` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '样式属性（其他样式扩展）',
  `list_class` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '表格回显样式',
  `is_default` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT 'N' COMMENT '是否默认（Y是 N否）',
  `status` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '0' COMMENT '状态（0正常 1停用）',
  `create_by` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`dict_code`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3807 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '字典数据表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for sys_dict_type
-- ----------------------------
DROP TABLE IF EXISTS `sys_dict_type`;
CREATE TABLE `sys_dict_type`  (
  `dict_id` bigint(11) NOT NULL AUTO_INCREMENT COMMENT '字典主键',
  `dict_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '字典名称',
  `dict_type` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '字典类型',
  `status` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '0' COMMENT '状态（0正常 1停用）',
  `create_by` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`dict_id`) USING BTREE,
  UNIQUE INDEX `dict_type`(`dict_type`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 102 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '字典类型表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for sys_job
-- ----------------------------
DROP TABLE IF EXISTS `sys_job`;
CREATE TABLE `sys_job`  (
  `job_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '任务ID',
  `job_name` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '任务名称',
  `job_group` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '任务组名',
  `method_name` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '任务方法',
  `method_params` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '方法参数',
  `cron_expression` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT 'cron执行表达式',
  `misfire_policy` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '3' COMMENT '计划执行错误策略（1立即执行 2执行一次 3放弃执行）',
  `status` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '0' COMMENT '状态（0正常 1暂停）',
  `create_by` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '备注信息',
  PRIMARY KEY (`job_id`, `job_name`, `job_group`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '定时任务调度表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for sys_job_log
-- ----------------------------
DROP TABLE IF EXISTS `sys_job_log`;
CREATE TABLE `sys_job_log`  (
  `job_log_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '任务日志ID',
  `job_name` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '任务名称',
  `job_group` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '任务组名',
  `method_name` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '任务方法',
  `method_params` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '方法参数',
  `job_message` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '日志信息',
  `status` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '0' COMMENT '执行状态（0正常 1失败）',
  `exception_info` varchar(2000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '异常信息',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`job_log_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 11351 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '定时任务调度日志表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for sys_logininfor
-- ----------------------------
DROP TABLE IF EXISTS `sys_logininfor`;
CREATE TABLE `sys_logininfor`  (
  `info_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '访问ID',
  `login_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '登录账号',
  `ipaddr` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '登录IP地址',
  `login_location` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '登录地点',
  `browser` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '浏览器类型',
  `os` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '操作系统',
  `status` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '0' COMMENT '登录状态（0成功 1失败）',
  `msg` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '提示消息',
  `login_time` datetime(0) NULL DEFAULT NULL COMMENT '访问时间',
  PRIMARY KEY (`info_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 180 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '系统访问记录' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for sys_menu
-- ----------------------------
DROP TABLE IF EXISTS `sys_menu`;
CREATE TABLE `sys_menu`  (
  `menu_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '菜单ID',
  `menu_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '菜单名称',
  `parent_id` int(11) NULL DEFAULT 0 COMMENT '父菜单ID',
  `order_num` int(4) NULL DEFAULT 0 COMMENT '显示顺序',
  `url` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '#' COMMENT '请求地址',
  `menu_type` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '菜单类型（M目录 C菜单 F按钮）',
  `visible` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '0' COMMENT '菜单状态（0显示 1隐藏）',
  `perms` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '权限标识',
  `icon` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '#' COMMENT '菜单图标',
  `create_by` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '备注',
  PRIMARY KEY (`menu_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1058 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '菜单权限表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for sys_notice
-- ----------------------------
DROP TABLE IF EXISTS `sys_notice`;
CREATE TABLE `sys_notice`  (
  `notice_id` int(4) NOT NULL AUTO_INCREMENT COMMENT '公告ID',
  `notice_title` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '公告标题',
  `notice_type` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '公告类型（1通知 2公告）',
  `notice_content` varchar(2000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '公告内容',
  `status` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '0' COMMENT '公告状态（0正常 1关闭）',
  `create_by` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`notice_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '通知公告表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for sys_oper_log
-- ----------------------------
DROP TABLE IF EXISTS `sys_oper_log`;
CREATE TABLE `sys_oper_log`  (
  `oper_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '日志主键',
  `title` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '模块标题',
  `business_type` int(2) NULL DEFAULT 0 COMMENT '业务类型（0其它 1新增 2修改 3删除）',
  `method` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '方法名称',
  `operator_type` int(1) NULL DEFAULT 0 COMMENT '操作类别（0其它 1后台用户 2手机端用户）',
  `oper_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '操作人员',
  `dept_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '部门名称',
  `oper_url` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '请求URL',
  `oper_ip` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '主机地址',
  `oper_location` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '操作地点',
  `oper_param` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '请求参数',
  `status` int(1) NULL DEFAULT 0 COMMENT '操作状态（0正常 1异常）',
  `error_msg` varchar(2000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '错误消息',
  `oper_time` datetime(0) NULL DEFAULT NULL COMMENT '操作时间',
  PRIMARY KEY (`oper_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 221 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '操作日志记录' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for sys_post
-- ----------------------------
DROP TABLE IF EXISTS `sys_post`;
CREATE TABLE `sys_post`  (
  `post_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '岗位ID',
  `post_code` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '岗位编码',
  `post_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '岗位名称',
  `post_sort` int(4) NOT NULL COMMENT '显示顺序',
  `status` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '状态（0正常 1停用）',
  `create_by` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`post_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '岗位信息表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for sys_role
-- ----------------------------
DROP TABLE IF EXISTS `sys_role`;
CREATE TABLE `sys_role`  (
  `role_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '角色ID',
  `role_name` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '角色名称',
  `role_key` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '角色权限字符串',
  `role_sort` int(4) NOT NULL COMMENT '显示顺序',
  `data_scope` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '1' COMMENT '数据范围（1：全部数据权限 2：自定数据权限）',
  `status` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '角色状态（0正常 1停用）',
  `del_flag` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  `create_by` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`role_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '角色信息表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for sys_role_dept
-- ----------------------------
DROP TABLE IF EXISTS `sys_role_dept`;
CREATE TABLE `sys_role_dept`  (
  `role_id` int(11) NOT NULL COMMENT '角色ID',
  `dept_id` int(11) NOT NULL COMMENT '部门ID',
  PRIMARY KEY (`role_id`, `dept_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '角色和部门关联表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for sys_role_menu
-- ----------------------------
DROP TABLE IF EXISTS `sys_role_menu`;
CREATE TABLE `sys_role_menu`  (
  `role_id` int(11) NOT NULL COMMENT '角色ID',
  `menu_id` int(11) NOT NULL COMMENT '菜单ID',
  PRIMARY KEY (`role_id`, `menu_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '角色和菜单关联表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for sys_user
-- ----------------------------
DROP TABLE IF EXISTS `sys_user`;
CREATE TABLE `sys_user`  (
  `user_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `dept_id` int(11) NULL DEFAULT NULL COMMENT '部门ID',
  `login_name` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '登录账号',
  `user_name` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '用户昵称',
  `user_type` varchar(2) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '00' COMMENT '用户类型（00系统用户）',
  `email` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '用户邮箱',
  `phonenumber` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '手机号码',
  `sex` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '0' COMMENT '用户性别（0男 1女 2未知）',
  `avatar` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '头像路径',
  `password` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '密码',
  `salt` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '盐加密',
  `status` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '0' COMMENT '帐号状态（0正常 1停用）',
  `del_flag` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  `login_ip` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '最后登陆IP',
  `login_date` datetime(0) NULL DEFAULT NULL COMMENT '最后登陆时间',
  `create_by` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '备注',
  PRIMARY KEY (`user_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '用户信息表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for sys_user_online
-- ----------------------------
DROP TABLE IF EXISTS `sys_user_online`;
CREATE TABLE `sys_user_online`  (
  `sessionId` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '用户会话id',
  `login_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '登录账号',
  `dept_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '部门名称',
  `ipaddr` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '登录IP地址',
  `login_location` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '登录地点',
  `browser` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '浏览器类型',
  `os` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '操作系统',
  `status` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '在线状态on_line在线off_line离线',
  `start_timestamp` datetime(0) NULL DEFAULT NULL COMMENT 'session创建时间',
  `last_access_time` datetime(0) NULL DEFAULT NULL COMMENT 'session最后访问时间',
  `expire_time` int(5) NULL DEFAULT 0 COMMENT '超时时间，单位为分钟',
  PRIMARY KEY (`sessionId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '在线用户记录' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for sys_user_post
-- ----------------------------
DROP TABLE IF EXISTS `sys_user_post`;
CREATE TABLE `sys_user_post`  (
  `user_id` int(11) NOT NULL COMMENT '用户ID',
  `post_id` int(11) NOT NULL COMMENT '岗位ID',
  PRIMARY KEY (`user_id`, `post_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '用户与岗位关联表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for sys_user_role
-- ----------------------------
DROP TABLE IF EXISTS `sys_user_role`;
CREATE TABLE `sys_user_role`  (
  `user_id` int(11) NOT NULL COMMENT '用户ID',
  `role_id` int(11) NOT NULL COMMENT '角色ID',
  PRIMARY KEY (`user_id`, `role_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '用户和角色关联表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_agricultural_machine
-- ----------------------------
DROP TABLE IF EXISTS `tb_agricultural_machine`;
CREATE TABLE `tb_agricultural_machine`  (
  `machine_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '农机ID',
  `farm_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '农场ID',
  `machine_type_id` bigint(20) NULL DEFAULT NULL COMMENT '农机类型ID',
  `name` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '农机名称',
  `model` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '农机型号',
  `price` decimal(13, 2) NULL DEFAULT NULL COMMENT '价格',
  `image` varchar(80) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '图片',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`machine_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 53 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '农机表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_alarm_day_time
-- ----------------------------
DROP TABLE IF EXISTS `tb_alarm_day_time`;
CREATE TABLE `tb_alarm_day_time`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '阈值ID',
  `farm_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '农场ID',
  `plot_id` bigint(20) NULL DEFAULT NULL COMMENT '地块ID',
  `day_start_time` time(0) NULL DEFAULT NULL COMMENT '白天开始时间',
  `day_end_time` time(0) NULL DEFAULT NULL COMMENT '白天结束时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 13 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '监控中心--白天报警时间段' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_alarm_record
-- ----------------------------
DROP TABLE IF EXISTS `tb_alarm_record`;
CREATE TABLE `tb_alarm_record`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `farm_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '农场ID',
  `plot_id` bigint(20) NOT NULL COMMENT '地块ID',
  `dev_id` bigint(20) NULL DEFAULT NULL COMMENT '设备ID',
  `dev_type` tinyint(4) NULL DEFAULT NULL COMMENT '设备类型（0监测设备，1气象站，2灌溉设备，3控制设备，4摄像头）',
  `types_index` smallint(6) NOT NULL COMMENT '报警阈值类型Index',
  `real_value` float NULL DEFAULT NULL COMMENT '监测到的数值',
  `less_or_more` tinyint(4) NULL DEFAULT NULL COMMENT '小于或者大于阈值（小于0，大于1）',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 76144 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '报警记录表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_alarm_threshold
-- ----------------------------
DROP TABLE IF EXISTS `tb_alarm_threshold`;
CREATE TABLE `tb_alarm_threshold`  (
  `alarm_threshold_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '阈值ID',
  `types_index` int(11) NOT NULL COMMENT '阈值类型index',
  `farm_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '农场ID',
  `plot_id` bigint(20) NULL DEFAULT NULL COMMENT '地块ID',
  `day_min_value` float NULL DEFAULT NULL COMMENT '白天阈值小的那个值',
  `day_max_value` float NULL DEFAULT NULL COMMENT '白天阈值大的那个值',
  `night_min_value` float NULL DEFAULT NULL COMMENT '晚上阈值小的值',
  `night_max_value` float NULL DEFAULT NULL COMMENT '夜晚阈值大的那个值',
  PRIMARY KEY (`alarm_threshold_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 94 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '报警阈值表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_am_type
-- ----------------------------
DROP TABLE IF EXISTS `tb_am_type`;
CREATE TABLE `tb_am_type`  (
  `machine_type_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '农机类型ID',
  `farm_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '农场id,UUID',
  `type_name` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '类型名称',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`machine_type_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 14 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '农机类型' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_article
-- ----------------------------
DROP TABLE IF EXISTS `tb_article`;
CREATE TABLE `tb_article`  (
  `material_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '物品ID',
  `material_type_id` bigint(20) NULL DEFAULT NULL COMMENT '物品类型ID',
  `material_name` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '物品名称',
  `brand` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '品牌',
  `meter_unit_id` bigint(10) NULL DEFAULT NULL COMMENT '计量单位(同时也是 多单位中的最小单位 )',
  `price` decimal(13, 2) NULL DEFAULT NULL COMMENT '单价',
  `price_unit_id` bigint(10) NULL DEFAULT NULL COMMENT '单价对应的单位id',
  `unit_id1` bigint(10) NULL DEFAULT NULL COMMENT '副单位1',
  `conversion_ratio1` double(11, 2) NULL DEFAULT NULL COMMENT '换算比例1',
  `unit_id2` bigint(10) NULL DEFAULT NULL COMMENT '副单位2',
  `conversion_ratio2` double(11, 2) NULL DEFAULT NULL COMMENT '换算比例2',
  `multiple_unit` int(1) NULL DEFAULT 0 COMMENT '启用多单位，0为不启动，1为启动',
  `image` varchar(80) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '物品图片',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建人',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新人',
  `farm_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '农场ID',
  PRIMARY KEY (`material_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 59 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '物品表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_article_type
-- ----------------------------
DROP TABLE IF EXISTS `tb_article_type`;
CREATE TABLE `tb_article_type`  (
  `material_type_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '物品类型ID',
  `type_name` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '物品类型',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建人',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新人',
  `farm_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '农场id,UUID',
  PRIMARY KEY (`material_type_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 16 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '物品类型表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_camera_image
-- ----------------------------
DROP TABLE IF EXISTS `tb_camera_image`;
CREATE TABLE `tb_camera_image`  (
  `pic_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '图像ID',
  `dev_id` bigint(20) NULL DEFAULT NULL COMMENT '对应设备id',
  `loc` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '存储位置',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `farm_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '农场id,UUID',
  PRIMARY KEY (`pic_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2242 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '摄像头拍照记录' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_crop_category
-- ----------------------------
DROP TABLE IF EXISTS `tb_crop_category`;
CREATE TABLE `tb_crop_category`  (
  `crop_category_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `category_name` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '作物名称',
  `category_status` tinyint(4) NULL DEFAULT 0 COMMENT '作物状态',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建人',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新人',
  `farm_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '农场id',
  `sample_picture` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '农作物样本图片地址',
  PRIMARY KEY (`crop_category_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 507 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '农作物种类表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_crop_type
-- ----------------------------
DROP TABLE IF EXISTS `tb_crop_type`;
CREATE TABLE `tb_crop_type`  (
  `crop_type_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `crop_name` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '作物名称',
  `crop_status` tinyint(4) NULL DEFAULT 0 COMMENT '作物状态',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建人',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新人',
  `farm_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '农场id',
  `crop_category_id` bigint(20) NULL DEFAULT NULL COMMENT '农作物种类表ID',
  PRIMARY KEY (`crop_type_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 37 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '农作物品种表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_dic_device_group
-- ----------------------------
DROP TABLE IF EXISTS `tb_dic_device_group`;
CREATE TABLE `tb_dic_device_group`  (
  `dev_group_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `dev_id` bigint(20) NULL DEFAULT NULL COMMENT '设备id',
  `group_id` bigint(20) NULL DEFAULT NULL COMMENT '所在分组id',
  `status` tinyint(4) NULL DEFAULT NULL COMMENT '是否有效（0有效，1无效）',
  PRIMARY KEY (`dev_group_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '设备与分组关联表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_dic_role_power
-- ----------------------------
DROP TABLE IF EXISTS `tb_dic_role_power`;
CREATE TABLE `tb_dic_role_power`  (
  `role_id` bigint(20) NOT NULL COMMENT '角色ID',
  `power_id` bigint(20) NOT NULL COMMENT '权限ID',
  PRIMARY KEY (`role_id`, `power_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '角色权限关联表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_farm
-- ----------------------------
DROP TABLE IF EXISTS `tb_farm`;
CREATE TABLE `tb_farm`  (
  `farm_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '农场id,UUID',
  `farm_name` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '名称',
  `country` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '国家',
  `region` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '地区',
  `farm_sequence` int(11) NULL DEFAULT NULL COMMENT '序列',
  `farm_status` tinyint(4) NULL DEFAULT 0 COMMENT '状态，0-正常，1-删除',
  `longitude` decimal(11, 7) NULL DEFAULT NULL COMMENT '经度',
  `latitude` decimal(10, 7) NULL DEFAULT NULL COMMENT '纬度',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建人',
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新人',
  PRIMARY KEY (`farm_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '农场表(基础表)' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_farm_merchant
-- ----------------------------
DROP TABLE IF EXISTS `tb_farm_merchant`;
CREATE TABLE `tb_farm_merchant`  (
  `farm_merchant_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `farm_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '农场id',
  `merchant_id` bigint(20) NULL DEFAULT NULL COMMENT '商户id',
  PRIMARY KEY (`farm_merchant_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 47 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '商户和农场关联表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_farm_user
-- ----------------------------
DROP TABLE IF EXISTS `tb_farm_user`;
CREATE TABLE `tb_farm_user`  (
  `user_id` bigint(20) NULL DEFAULT NULL COMMENT '用户ID',
  `role_id` bigint(20) NULL DEFAULT NULL COMMENT '角色ID',
  `farm_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '农场ID',
  UNIQUE INDEX `user_role_farm`(`user_id`, `role_id`, `farm_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '用户角色农场关联表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_farming_plan
-- ----------------------------
DROP TABLE IF EXISTS `tb_farming_plan`;
CREATE TABLE `tb_farming_plan`  (
  `plan_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `plan_type` varchar(8) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '计划类型(0普通计划，1标准，2智能)',
  `farming_type_id` bigint(20) NULL DEFAULT NULL COMMENT '农事类型id',
  `work_hours` double(10, 1) NULL DEFAULT NULL COMMENT '投入工时',
  `start_time` datetime(0) NULL DEFAULT NULL COMMENT '开始时间',
  `end_time` datetime(0) NULL DEFAULT NULL COMMENT '结束时间',
  `plan_repeat` tinyint(4) NULL DEFAULT 0 COMMENT '是否重复(0否，1重复)',
  `plan_repeat_data` int(4) NULL DEFAULT NULL COMMENT '重复天数（plan_repeat=1就是重复）',
  `plan_repeat_plan_id` bigint(20) NULL DEFAULT NULL COMMENT '如果选中了重复，此农事计划就是最初的  农事计划ID',
  `machine_id` varchar(1024) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '农机id(多个以分号隔开)',
  `remark` varchar(512) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '备注',
  `plan_status` tinyint(4) NULL DEFAULT 0 COMMENT '计划状态 0 正常 1删除 2已转化,已完成',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建人code',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新人修改人code',
  `farm_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '农场id,UUID',
  `is_lntelligence` tinyint(4) NULL DEFAULT 0 COMMENT '是否智能计划 0 不是 1是',
  `data_id` bigint(11) NULL DEFAULT 0,
  PRIMARY KEY (`plan_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 317 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '农事计划表（普通计划，智能计划）' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_farming_plan_implement
-- ----------------------------
DROP TABLE IF EXISTS `tb_farming_plan_implement`;
CREATE TABLE `tb_farming_plan_implement`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `plan_id` bigint(20) NULL DEFAULT NULL COMMENT '农事计划ID',
  `dev_id` bigint(20) NULL DEFAULT NULL COMMENT '设备ID',
  `types_index` bigint(20) NULL DEFAULT NULL COMMENT '传感器标识',
  `condition_var` int(11) NULL DEFAULT 0 COMMENT '条件 0 大于 1大于等于 2小于 3小于等于 4 等于',
  `data_var` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '值',
  `status` int(11) NULL DEFAULT 0 COMMENT '0 未执行 1 删除  2已执行 ',
  `thingsboard_key` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '物联网端关键字',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 94 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '智能计划执行表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_farming_plan_standard
-- ----------------------------
DROP TABLE IF EXISTS `tb_farming_plan_standard`;
CREATE TABLE `tb_farming_plan_standard`  (
  `plan_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `crop_category_id` bigint(20) NULL DEFAULT NULL COMMENT '作物种类id',
  `plant_standard` varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '种植标准',
  `plant_enviroment` varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '作物环境',
  `model_id` bigint(20) NULL DEFAULT NULL COMMENT '作物模型id',
  `period_id` bigint(20) NULL DEFAULT NULL COMMENT '模型阶段id',
  `farming_id` bigint(20) NULL DEFAULT NULL COMMENT '阶段的农事id',
  `plot_id` bigint(20) NULL DEFAULT NULL COMMENT '地块id',
  `sub_plot_id` bigint(20) NULL DEFAULT NULL COMMENT '子地块id',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建人',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新人',
  `farm_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '农场id,UUID',
  PRIMARY KEY (`plan_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '计划-标准种植流程表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_farming_record
-- ----------------------------
DROP TABLE IF EXISTS `tb_farming_record`;
CREATE TABLE `tb_farming_record`  (
  `record_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `farming_type_id` bigint(20) NULL DEFAULT NULL COMMENT '农事类型id',
  `start_time` datetime(0) NULL DEFAULT NULL COMMENT '开始时间',
  `end_time` datetime(0) NULL DEFAULT NULL COMMENT '结束时间',
  `machine_id` bigint(20) NULL DEFAULT NULL COMMENT '农机id',
  `record_note` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '农事笔记',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建人',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新人',
  `farm_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '农场id,UUID',
  PRIMARY KEY (`record_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '农事记录表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_farming_type
-- ----------------------------
DROP TABLE IF EXISTS `tb_farming_type`;
CREATE TABLE `tb_farming_type`  (
  `farming_type_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `farming_type_name` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '农事类型名称',
  `farming_type_status` tinyint(4) NULL DEFAULT 0 COMMENT '类型状态',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建人',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新人',
  `farm_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '农场id',
  `tpye_record` int(1) NULL DEFAULT 3 COMMENT '记录类型（1施肥记录，2用药记录，3劳作记录）',
  PRIMARY KEY (`farming_type_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 22 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '农事类型' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_goods_img
-- ----------------------------
DROP TABLE IF EXISTS `tb_goods_img`;
CREATE TABLE `tb_goods_img`  (
  `img_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `img_url` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '图片url',
  `img_sequence` tinyint(4) NULL DEFAULT NULL COMMENT '图片序列',
  `img_status` tinyint(4) NULL DEFAULT 1 COMMENT '状态，0-删除,1-正常 ',
  `goods_id` bigint(20) NULL DEFAULT NULL COMMENT '商品id',
  PRIMARY KEY (`img_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 297 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '商品图片表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_harvest
-- ----------------------------
DROP TABLE IF EXISTS `tb_harvest`;
CREATE TABLE `tb_harvest`  (
  `harvest_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `plot_id` bigint(20) NULL DEFAULT NULL COMMENT '地块id',
  `sub_plot_id` bigint(20) NULL DEFAULT NULL COMMENT '子地块id',
  `harvest_spec_id` bigint(20) NULL DEFAULT NULL COMMENT '主键id',
  `harvest_time` datetime(0) NULL DEFAULT NULL COMMENT '采收时间',
  `harvest_amount` double(11, 2) NULL DEFAULT NULL COMMENT '采收总量（KG）',
  `crop_level` varchar(6) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '作物等级',
  `fresh_day` double(11, 1) NULL DEFAULT NULL COMMENT '保鲜期(天)',
  `user_id` varchar(1024) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '成员id，多个已逗号隔开',
  `user_name` varchar(1024) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '成员名称，多个已逗号隔开',
  `remark` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '备注',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建人',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新人',
  `farm_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '农场id,UUID',
  `planting_id` bigint(20) NULL DEFAULT NULL COMMENT '采集时当前的种植ID',
  `status` int(1) NULL DEFAULT 0 COMMENT '采收状态（0正常，1删除）',
  PRIMARY KEY (`harvest_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 54 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '作物采收表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_harvest_img
-- ----------------------------
DROP TABLE IF EXISTS `tb_harvest_img`;
CREATE TABLE `tb_harvest_img`  (
  `harvest_img_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `img_url` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '图片url',
  `img_sequence` int(11) NULL DEFAULT NULL COMMENT '序列',
  `harvest_id` bigint(20) NULL DEFAULT NULL COMMENT '采收id',
  PRIMARY KEY (`harvest_img_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 70 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '采收对应图片表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_harvest_spec
-- ----------------------------
DROP TABLE IF EXISTS `tb_harvest_spec`;
CREATE TABLE `tb_harvest_spec`  (
  `harvest_spec_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `spec_name` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '规格名称',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建人',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新人',
  `farm_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '农场id',
  PRIMARY KEY (`harvest_spec_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 18 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '采收规格表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_home_grade
-- ----------------------------
DROP TABLE IF EXISTS `tb_home_grade`;
CREATE TABLE `tb_home_grade`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `sort` int(11) NULL DEFAULT 0 COMMENT '排列顺序',
  `dict_value` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '字典值(对应 sys_dict_data 字段)',
  `farm_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '农场ID',
  `status` int(1) NULL DEFAULT 0 COMMENT '状态（0正常，1关闭）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 486 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '首页模块排列表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_inventory_material
-- ----------------------------
DROP TABLE IF EXISTS `tb_inventory_material`;
CREATE TABLE `tb_inventory_material`  (
  `warehouse_material_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `quantity` double(13, 2) NULL DEFAULT NULL COMMENT '数量',
  `alarm_stock` double(13, 2) NULL DEFAULT NULL COMMENT '报警库存',
  `material_id` bigint(20) NULL DEFAULT NULL COMMENT '物品id',
  `warehouse_id` bigint(20) NULL DEFAULT NULL COMMENT '仓库ID',
  `farm_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '农场id,UUID',
  PRIMARY KEY (`warehouse_material_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 42 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '仓库和物品关联表(库存)' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_irrigation_device
-- ----------------------------
DROP TABLE IF EXISTS `tb_irrigation_device`;
CREATE TABLE `tb_irrigation_device`  (
  `device_id` bigint(20) NOT NULL COMMENT '设备id',
  `group_id` bigint(20) NOT NULL COMMENT '灌溉分组id',
  PRIMARY KEY (`device_id`, `group_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '灌溉分组设备中间表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_irrigation_device_img
-- ----------------------------
DROP TABLE IF EXISTS `tb_irrigation_device_img`;
CREATE TABLE `tb_irrigation_device_img`  (
  `img_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `img_url` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '图片地址',
  `device_id` bigint(20) NULL DEFAULT NULL COMMENT '灌溉设备id',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建人',
  `farm_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '农场id,UUID',
  PRIMARY KEY (`img_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 30 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '灌溉设备图片表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_irrigation_fix_quantity
-- ----------------------------
DROP TABLE IF EXISTS `tb_irrigation_fix_quantity`;
CREATE TABLE `tb_irrigation_fix_quantity`  (
  `fix_quantity_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `device_id` bigint(20) NULL DEFAULT NULL COMMENT '设备id',
  `sensor` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '传感器',
  `contrast` bigint(20) NULL DEFAULT NULL COMMENT '大于或者小于,字典表数据',
  `contrast_condition` int(11) NULL DEFAULT NULL COMMENT '对比条件',
  `open_close` bigint(20) NULL DEFAULT 0 COMMENT '打开或者关闭，0-打开，1-关闭',
  `action_time` int(11) NULL DEFAULT NULL COMMENT '操作时间',
  `time_unit` varchar(8) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '时间单位',
  `fix_quantity_status` tinyint(4) NULL DEFAULT 0 COMMENT '定量状态,0-未激活，1-已激活',
  `group_id` bigint(20) NULL DEFAULT NULL COMMENT '灌溉分组id',
  PRIMARY KEY (`fix_quantity_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 9 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '灌溉分组定量表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_irrigation_group
-- ----------------------------
DROP TABLE IF EXISTS `tb_irrigation_group`;
CREATE TABLE `tb_irrigation_group`  (
  `group_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `group_name` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '分组名',
  `group_status` tinyint(4) NULL DEFAULT 0 COMMENT '分组状态,0-关闭全部，1-打开全部，2-删除',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建人',
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新人',
  `farm_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '农场id',
  PRIMARY KEY (`group_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 13 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '灌溉中心分组表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_irrigation_log
-- ----------------------------
DROP TABLE IF EXISTS `tb_irrigation_log`;
CREATE TABLE `tb_irrigation_log`  (
  `action_log_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `action_type` varchar(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '操作类型，M-手动，A-自动',
  `action_content` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '操作内容',
  `group_name` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '操作分组名',
  `action_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '操作时间',
  `action_by` bigint(20) NULL DEFAULT NULL,
  `farm_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '农场id',
  PRIMARY KEY (`action_log_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 89 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '灌溉操作日志表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_irrigation_timing
-- ----------------------------
DROP TABLE IF EXISTS `tb_irrigation_timing`;
CREATE TABLE `tb_irrigation_timing`  (
  `timing_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `open_time` varchar(5) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '几点打开',
  `open_period` int(11) NULL DEFAULT NULL COMMENT '打开多长时间',
  `time_unit` varchar(8) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '时间单位',
  `loop_or_not` tinyint(4) NULL DEFAULT 0 COMMENT '是否循环0-循环，1-不循环',
  `loop_count` int(11) NULL DEFAULT NULL COMMENT '循环几次',
  `spacing_time` int(11) NULL DEFAULT NULL COMMENT '间隔多久',
  `spacing_period` varchar(8) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '间隔时间单位',
  `timing_status` tinyint(4) NULL DEFAULT 0 COMMENT '定时状态0-未激活，1-已激活',
  `group_id` bigint(20) NULL DEFAULT NULL COMMENT '灌溉分组id',
  PRIMARY KEY (`timing_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 13 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '灌溉分组定时表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_merchant
-- ----------------------------
DROP TABLE IF EXISTS `tb_merchant`;
CREATE TABLE `tb_merchant`  (
  `merchant_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `merchant_code` bigint(20) NULL DEFAULT NULL,
  `nick_name` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '昵称',
  `head_url` varchar(256) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '头像',
  `account` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '账号',
  `phone` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '手机号',
  `password` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '密码',
  `email` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '用户邮箱',
  `company_name` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '公司名称',
  `status` smallint(6) NULL DEFAULT 0 COMMENT '商户状态(0-未开通，1-已开通，2-删除)',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建人',
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新人',
  `role_id` bigint(20) NULL DEFAULT NULL COMMENT '角色ID',
  PRIMARY KEY (`merchant_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 15 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '商户表（超级管理员，注册用户）' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_message_record
-- ----------------------------
DROP TABLE IF EXISTS `tb_message_record`;
CREATE TABLE `tb_message_record`  (
  `message_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `message_type` int(1) NULL DEFAULT NULL COMMENT '消息类型 0是报警消息 1是任务消息',
  `message_subject` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '消息主题',
  `message_content` varchar(4000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '消息内容',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `message_status` int(2) NULL DEFAULT NULL COMMENT '消息状态 （0未读  1已读）',
  `send_user_id` bigint(20) NULL DEFAULT NULL COMMENT '发送方用户id',
  `receive_user_id` bigint(20) NULL DEFAULT NULL COMMENT '接收方用户id',
  `farm_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '农场ID',
  PRIMARY KEY (`message_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 73870 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '消息记录表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_model
-- ----------------------------
DROP TABLE IF EXISTS `tb_model`;
CREATE TABLE `tb_model`  (
  `model_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `model_name` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '模型名称',
  `model_type` varchar(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '模型类型，F-农场模型，S-系统模型',
  `crop_category_id` bigint(20) NULL DEFAULT NULL COMMENT '作物种类id',
  `plant_standard_id` bigint(20) NULL DEFAULT NULL COMMENT '作物标准id',
  `plant_environment_id` bigint(20) NULL DEFAULT NULL COMMENT '作物环境id',
  `model_status` tinyint(4) NULL DEFAULT 0 COMMENT '模型状态',
  `model_use_time` int(11) NULL DEFAULT 0 COMMENT '模型使用次数',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建人',
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新人',
  `farm_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`model_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 38 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '作物模型表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_model_period
-- ----------------------------
DROP TABLE IF EXISTS `tb_model_period`;
CREATE TABLE `tb_model_period`  (
  `period_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `period_name` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '阶段名称',
  `start_time` varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '开始时间-字符串类型',
  `end_time` varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '结束时间-字符串类型',
  `model_id` bigint(20) NULL DEFAULT NULL COMMENT '作物模型id',
  PRIMARY KEY (`period_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 42 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '作物模型-阶段表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_model_period_farming
-- ----------------------------
DROP TABLE IF EXISTS `tb_model_period_farming`;
CREATE TABLE `tb_model_period_farming`  (
  `farming_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `plant_type` varchar(6) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '定植类型',
  `plant_day` int(11) NULL DEFAULT NULL COMMENT '定植天数',
  `farming_type_id` bigint(20) NULL DEFAULT NULL COMMENT '农事类型id',
  `farming_requirements` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '农事要求',
  `period_id` bigint(20) NULL DEFAULT NULL COMMENT '模型阶段id',
  PRIMARY KEY (`farming_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 50 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '作物模型-阶段农事表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_pay_log
-- ----------------------------
DROP TABLE IF EXISTS `tb_pay_log`;
CREATE TABLE `tb_pay_log`  (
  `log_id` int(20) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '日志ID',
  `user_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '管理员ID',
  `farm_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '农场ID',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `spend_time` int(11) NULL DEFAULT NULL COMMENT '耗时',
  `method` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '请求类型',
  `user_agent` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '用户标识',
  `user_ip` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '用户IP',
  `opt_content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '请求内容',
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '请求路径',
  `opt_result` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  PRIMARY KEY (`log_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 105150 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '日志记录表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_plan_img
-- ----------------------------
DROP TABLE IF EXISTS `tb_plan_img`;
CREATE TABLE `tb_plan_img`  (
  `plan_img_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `img_url` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '图片url',
  `img_sequence` int(11) NULL DEFAULT NULL COMMENT '序列',
  `plan_id` bigint(20) NULL DEFAULT NULL COMMENT '计划id',
  PRIMARY KEY (`plan_img_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 253 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '计划对应图片表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_plan_material
-- ----------------------------
DROP TABLE IF EXISTS `tb_plan_material`;
CREATE TABLE `tb_plan_material`  (
  `plan_material_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `warehouse_id` bigint(20) NULL DEFAULT NULL COMMENT '仓库id',
  `material_id` bigint(20) NULL DEFAULT NULL COMMENT '物品id',
  `material_amount` int(11) NULL DEFAULT NULL COMMENT '数量',
  `material_unit` varchar(5) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '物品单位',
  `plan_id` bigint(20) NULL DEFAULT NULL COMMENT '计划id',
  PRIMARY KEY (`plan_material_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 427 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '计划使用的物品表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_plan_message
-- ----------------------------
DROP TABLE IF EXISTS `tb_plan_message`;
CREATE TABLE `tb_plan_message`  (
  `message_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `message_content` varchar(4000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '消息内容',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `create_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '创建人(添加记录的人)',
  `plan_id` bigint(20) NULL DEFAULT NULL COMMENT '农事计划id',
  `img_url` varchar(4000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '图片地址，多个已分号隔开（;）',
  `status` int(1) NULL DEFAULT 0 COMMENT '状态（0正常，1删除）',
  PRIMARY KEY (`message_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 54 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '农事记录消息表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_plan_participant
-- ----------------------------
DROP TABLE IF EXISTS `tb_plan_participant`;
CREATE TABLE `tb_plan_participant`  (
  `plan_user_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `responser_id` bigint(20) NULL DEFAULT NULL COMMENT '责任人userCode',
  `participant_id` bigint(20) NULL DEFAULT NULL COMMENT '参与人userCode',
  `plan_id` bigint(20) NULL DEFAULT NULL COMMENT '计划id',
  `sub_plot_id` bigint(11) NULL DEFAULT NULL COMMENT '子地块id',
  PRIMARY KEY (`plan_user_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 891 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '农事计划参与者表(包括负责人和成员)' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_plan_plot
-- ----------------------------
DROP TABLE IF EXISTS `tb_plan_plot`;
CREATE TABLE `tb_plan_plot`  (
  `plan_plot_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `plot_id` bigint(20) NULL DEFAULT NULL COMMENT '地块id',
  `sub_plot_id` bigint(20) NULL DEFAULT NULL COMMENT '子地块id',
  `plan_id` bigint(20) NULL DEFAULT NULL COMMENT '计划id',
  PRIMARY KEY (`plan_plot_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 359 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '计划对应的地块表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_planting
-- ----------------------------
DROP TABLE IF EXISTS `tb_planting`;
CREATE TABLE `tb_planting`  (
  `planting_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `crop_category_id` bigint(20) NULL DEFAULT NULL COMMENT '作物种类id',
  `crop_type_id` bigint(20) NULL DEFAULT NULL COMMENT '作物品种',
  `plant_time` datetime(0) NULL DEFAULT NULL COMMENT '定植时间',
  `end_time` datetime(0) NULL DEFAULT NULL COMMENT '预计结束时间',
  `plant_standard` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '种植标准(无公害，有机，绿色)',
  `planting_status` tinyint(4) NULL DEFAULT 0 COMMENT '种植状态(0-正常，1-删除，2-结束种植)',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建人',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新人',
  `plot_id` bigint(20) NULL DEFAULT NULL COMMENT '地块id',
  `sub_plot_id` bigint(20) NULL DEFAULT NULL COMMENT '子地块id',
  `farm_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '农场id',
  PRIMARY KEY (`planting_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 46 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '种植表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_plot
-- ----------------------------
DROP TABLE IF EXISTS `tb_plot`;
CREATE TABLE `tb_plot`  (
  `plot_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `plot_img` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '地块图片',
  `plot_name` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '地块名称',
  `region_id` bigint(20) NULL DEFAULT NULL COMMENT '地区id',
  `plot_acreage` double NULL DEFAULT NULL COMMENT '地块面积',
  `plot_type` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '类型',
  `plot_status` tinyint(4) NULL DEFAULT 0 COMMENT '状态',
  `plot_sequence` int(11) NULL DEFAULT NULL COMMENT '序列',
  `plot_color` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '地块颜色',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建人',
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新人',
  `farm_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`plot_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 102 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '地块表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_plot_coordinate
-- ----------------------------
DROP TABLE IF EXISTS `tb_plot_coordinate`;
CREATE TABLE `tb_plot_coordinate`  (
  `coordinate_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `latitude` decimal(10, 7) NULL DEFAULT NULL COMMENT '纬度',
  `longitude` decimal(11, 7) NULL DEFAULT NULL COMMENT '经度',
  `coordinate_status` tinyint(4) NULL DEFAULT 0 COMMENT '状态',
  `plot_id` bigint(20) NULL DEFAULT NULL,
  PRIMARY KEY (`coordinate_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 635 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '地块坐标表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_plot_field_pic
-- ----------------------------
DROP TABLE IF EXISTS `tb_plot_field_pic`;
CREATE TABLE `tb_plot_field_pic`  (
  `field_pic_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `pic_url` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '图片url',
  `pic_sequence` int(11) NULL DEFAULT NULL COMMENT '图片序列',
  `plot_id` bigint(20) NULL DEFAULT NULL COMMENT '地块id',
  PRIMARY KEY (`field_pic_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 122 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '地块对应实地图片表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_plot_region
-- ----------------------------
DROP TABLE IF EXISTS `tb_plot_region`;
CREATE TABLE `tb_plot_region`  (
  `region_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `region_name` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '类型名称',
  `region_status` tinyint(4) NULL DEFAULT 0 COMMENT '状态',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建人',
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新人',
  `farm_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '农场id',
  PRIMARY KEY (`region_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 22 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '地块区域表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_plot_report
-- ----------------------------
DROP TABLE IF EXISTS `tb_plot_report`;
CREATE TABLE `tb_plot_report`  (
  `report_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `report_name` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '报告名称',
  `report_company` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '检测单位',
  `report_time` date NULL DEFAULT NULL COMMENT '检测时间',
  `report_result` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '结论',
  `plot_id` bigint(20) NULL DEFAULT NULL COMMENT '地块id',
  PRIMARY KEY (`report_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 26 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '地块对应的水土质检报告表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_record_img
-- ----------------------------
DROP TABLE IF EXISTS `tb_record_img`;
CREATE TABLE `tb_record_img`  (
  `record_img_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `img_url` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '图片url',
  `img_sequence` int(11) NULL DEFAULT NULL COMMENT '序列',
  `record_id` bigint(20) NULL DEFAULT NULL COMMENT '记录id',
  PRIMARY KEY (`record_img_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '记录对应图片表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_record_material
-- ----------------------------
DROP TABLE IF EXISTS `tb_record_material`;
CREATE TABLE `tb_record_material`  (
  `record_material_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `warehouse_id` bigint(20) NULL DEFAULT NULL COMMENT '仓库id',
  `material_id` bigint(20) NULL DEFAULT NULL COMMENT '物品id',
  `material_amount` int(11) NULL DEFAULT NULL COMMENT '数量',
  `material_unit` varchar(5) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '物品单位',
  `record_id` bigint(20) NULL DEFAULT NULL COMMENT '记录id',
  PRIMARY KEY (`record_material_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '记录使用的物品表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_record_message
-- ----------------------------
DROP TABLE IF EXISTS `tb_record_message`;
CREATE TABLE `tb_record_message`  (
  `message_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `message_content` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '消息内容',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建人(添加记录的人)',
  `record_id` bigint(20) NULL DEFAULT NULL COMMENT '农事记录id',
  PRIMARY KEY (`message_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '农事记录消息表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_report_img
-- ----------------------------
DROP TABLE IF EXISTS `tb_report_img`;
CREATE TABLE `tb_report_img`  (
  `report_img_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `report_id` bigint(20) NULL DEFAULT NULL COMMENT '主键id',
  `img_url` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '图片url',
  `report_sequence` int(11) NULL DEFAULT NULL COMMENT '图片序列',
  PRIMARY KEY (`report_img_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 78 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '水质报告图片表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_res_device
-- ----------------------------
DROP TABLE IF EXISTS `tb_res_device`;
CREATE TABLE `tb_res_device`  (
  `dev_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '设备ID',
  `dev_name` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '设备名',
  `dev_num` varchar(48) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '设备序列号',
  `plot_id` bigint(20) NULL DEFAULT NULL COMMENT '地块id',
  `lng` double NULL DEFAULT NULL COMMENT '经度',
  `lat` double NULL DEFAULT NULL COMMENT '纬度',
  `electricity` float NULL DEFAULT NULL COMMENT '剩余电量（比如0.32表示还有32%的电量）',
  `dev_type` smallint(6) NULL DEFAULT NULL COMMENT '（0监测设备，1气象站，2自动化设备，4摄像头）',
  `last_photo_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '上次拍照时间（针对摄像头类型）',
  `shooting_interval` float NULL DEFAULT NULL COMMENT '拍摄间隔（以分钟计）--仅仅针对设备类型为摄像头类型',
  `status` tinyint(4) NULL DEFAULT NULL COMMENT '状态（0正报警，1运行中，2断开，3待机，4其它）',
  `farm_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '农场ID',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`dev_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 65 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '设备表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_res_device_attributes
-- ----------------------------
DROP TABLE IF EXISTS `tb_res_device_attributes`;
CREATE TABLE `tb_res_device_attributes`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `dev_id` bigint(20) NULL DEFAULT NULL COMMENT '设备ID',
  `attributes_name` varchar(60) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '属性名',
  `unit` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '单位',
  `thingsboard_key` varchar(40) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '物联网端关键字',
  `types_index` tinyint(4) NULL DEFAULT NULL COMMENT '设备类型列表(参考tb_alarm_threshold_types表)',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 103 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '设备属性（每个设备包含的属性记录）' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_res_power
-- ----------------------------
DROP TABLE IF EXISTS `tb_res_power`;
CREATE TABLE `tb_res_power`  (
  `power_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `power_code` varchar(40) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '权限编码',
  `name` varchar(40) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '中文名',
  `status` tinyint(4) NULL DEFAULT NULL COMMENT '状态（0有效，1无效）',
  `parent_id` bigint(20) NULL DEFAULT NULL COMMENT '父类ID',
  `uri` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '接口uri',
  `level` tinyint(4) NULL DEFAULT NULL COMMENT '(1-第一层级(分类作用),2-第二层级(菜单),3-第三层级(按钮),4-第四层级(接口),接口是挂在按钮下)',
  PRIMARY KEY (`power_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 253 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '权限表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_res_role
-- ----------------------------
DROP TABLE IF EXISTS `tb_res_role`;
CREATE TABLE `tb_res_role`  (
  `role_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '角色ID',
  `name` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '角色名',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `farm_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '农场ID',
  `status` tinyint(4) NULL DEFAULT NULL COMMENT '是否有效',
  PRIMARY KEY (`role_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 42 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '角色表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_sale
-- ----------------------------
DROP TABLE IF EXISTS `tb_sale`;
CREATE TABLE `tb_sale`  (
  `sale_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `harvest_id` bigint(20) NULL DEFAULT NULL COMMENT '采收id',
  `buyer_id` bigint(20) NULL DEFAULT NULL COMMENT '采购商id',
  `sale_date` datetime(0) NULL DEFAULT NULL COMMENT '采购日期',
  `sale_weight` double NULL DEFAULT NULL COMMENT '重量(KG)',
  `sale_spec_id` bigint(20) NULL DEFAULT NULL COMMENT '采购规格id',
  `sale_amount` double NULL DEFAULT NULL COMMENT '数量',
  `sale_unit` varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '单位',
  `total_money` double NULL DEFAULT NULL COMMENT '总金额(元)',
  `express_delivery` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '物流渠道',
  `delivery_no` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '物流单号',
  `delivery_area` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '发货省市区',
  `delivery_address` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '发货地址',
  `destination_area` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '收货省市区',
  `destination_address` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '收货地址',
  `messager` varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '送货人',
  `car_number` varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '车牌号',
  `phone` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '联系方式',
  `sale_status` tinyint(4) NULL DEFAULT 0 COMMENT '状态',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建人',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新人',
  `farm_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '农场id,UUID',
  PRIMARY KEY (`sale_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '作物销售表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_sale_buyer
-- ----------------------------
DROP TABLE IF EXISTS `tb_sale_buyer`;
CREATE TABLE `tb_sale_buyer`  (
  `buyer_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `buyer_name` varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '采购商',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建人',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新人',
  `farm_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '农场id',
  PRIMARY KEY (`buyer_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '销售-采购商' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_sale_spec
-- ----------------------------
DROP TABLE IF EXISTS `tb_sale_spec`;
CREATE TABLE `tb_sale_spec`  (
  `sale_spec_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `spec_name` varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '规格名称',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建人',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新人',
  `farm_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '农场id',
  PRIMARY KEY (`sale_spec_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '销售-规格表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_sale_templet
-- ----------------------------
DROP TABLE IF EXISTS `tb_sale_templet`;
CREATE TABLE `tb_sale_templet`  (
  `sale_templet_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `status` int(1) NULL DEFAULT 0 COMMENT '状态（0未发布，1已发布，2已删除）',
  `farm_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '农场名称',
  `farm_remark` varchar(4000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '农场介绍',
  `mall_link` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '商城链接',
  `contact_way` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '联系方式',
  `farm_address` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '农场地址',
  `is_map` int(1) NULL DEFAULT 0 COMMENT '是否选中地图（0未选中，1已选中）',
  `is_climate` int(1) NULL DEFAULT 0 COMMENT '是否选中气候条件（0未选中，1已选中）',
  `is_real_data` int(1) NULL DEFAULT 0 COMMENT '是否选中实时数据（0未选中，1已选中）',
  `is_real_picture` int(1) NULL DEFAULT 0 COMMENT '是否选中实时图像（0未选中，1已选中）',
  `is_activity` int(1) NULL DEFAULT 0 COMMENT '是否选中农业活动（0未选中，1已选中）',
  `create_date` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_date` datetime(0) NULL DEFAULT NULL COMMENT '修改时间',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建人',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新人',
  `farm_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '农场id,UUID',
  `qr_code_url` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '二维码路径',
  `corporate_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '企业名称',
  `corporate_address` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '企业地址',
  PRIMARY KEY (`sale_templet_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 30 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '销售管理-展示模板' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_sale_templet_info
-- ----------------------------
DROP TABLE IF EXISTS `tb_sale_templet_info`;
CREATE TABLE `tb_sale_templet_info`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `sale_templet_id` bigint(20) NULL DEFAULT NULL COMMENT '销售管理，展示模板ID',
  `name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '名称',
  `link` varchar(124) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '链接',
  `img_url` varchar(4000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '图片地址（多个图片已逗号隔开，）',
  `type` int(1) NULL DEFAULT NULL COMMENT '图片类型（1：农场图片栏，2报告栏，3证书栏，4产品栏）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 425 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '展示模板详情' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_sub_plot
-- ----------------------------
DROP TABLE IF EXISTS `tb_sub_plot`;
CREATE TABLE `tb_sub_plot`  (
  `sub_plot_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `sub_plot_name` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '子地块名称',
  `sub_plot_person` bigint(20) NULL DEFAULT NULL COMMENT '负责人code',
  `sub_plot_status` tinyint(4) NULL DEFAULT 0 COMMENT '子地块状态',
  `sub_plot_acreage` double NULL DEFAULT NULL COMMENT '子地块面积(亩)',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建人',
  `plot_id` bigint(20) NULL DEFAULT NULL COMMENT '地块id',
  PRIMARY KEY (`sub_plot_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 132 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '子地块表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_transfer
-- ----------------------------
DROP TABLE IF EXISTS `tb_transfer`;
CREATE TABLE `tb_transfer`  (
  `transfer_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `in_warehouse_id` bigint(20) NULL DEFAULT NULL COMMENT '调入仓库id',
  `out_warehouse_id` bigint(20) NULL DEFAULT NULL COMMENT '调出仓库id',
  `number` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '单号',
  `material_id` bigint(20) NULL DEFAULT NULL COMMENT '物品id',
  `article` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '物品名称',
  `type` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '物品类型名称 （冗余字段，目前也没用）',
  `method` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '方式 ：调出、调入 （目前没用，由程序中判断）',
  `unit` bigint(8) NULL DEFAULT NULL COMMENT '单位id',
  `quantity` double(13, 2) NULL DEFAULT NULL COMMENT '数量',
  `operator_id` bigint(32) NULL DEFAULT NULL COMMENT '操作人',
  `remarks` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '备注',
  `status` int(11) NULL DEFAULT 0 COMMENT '状态，0为在途，1为已调拨',
  `operate` int(11) NULL DEFAULT 0 COMMENT '操作，0显示入库，1不显示  （目前没用，由程序中判断）',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建人',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新人',
  `farm_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '农场ID',
  PRIMARY KEY (`transfer_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '调拨记录表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_unit_type
-- ----------------------------
DROP TABLE IF EXISTS `tb_unit_type`;
CREATE TABLE `tb_unit_type`  (
  `material_unit_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '单位ID',
  `type_name` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '单位类型',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建人',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新人',
  `farm_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '农场id,UUID',
  PRIMARY KEY (`material_unit_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 30 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '物品-单位表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_use_record
-- ----------------------------
DROP TABLE IF EXISTS `tb_use_record`;
CREATE TABLE `tb_use_record`  (
  `machine_record_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '农机使用记录ID',
  `plan` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '计划',
  `person` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '人员',
  `cost_time` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '耗时',
  `machine_id` bigint(20) NULL DEFAULT NULL COMMENT '农机id',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`machine_record_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 15 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '农机使用记录' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_user
-- ----------------------------
DROP TABLE IF EXISTS `tb_user`;
CREATE TABLE `tb_user`  (
  `user_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `head_url` varchar(256) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '用户头像地址',
  `account` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '账号，要么是手机号，要么是邮箱地址',
  `nick_name` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '昵称',
  `password` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '登录密码',
  `company_name` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '公司名称',
  `phone` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '手机号',
  `email` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '用户邮箱',
  `status` smallint(6) NULL DEFAULT 0 COMMENT '0正常 1停用',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建人',
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新人',
  `user_code` bigint(20) NULL DEFAULT NULL COMMENT '用户编码，表示跟tb_merchant保持唯一',
  PRIMARY KEY (`user_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 59 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '用户表（成员表）' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_user_copy
-- ----------------------------
DROP TABLE IF EXISTS `tb_user_copy`;
CREATE TABLE `tb_user_copy`  (
  `user_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `head_url` varchar(256) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '用户头像地址',
  `account` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '账号，要么是手机号，要么是邮箱地址',
  `nick_name` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '昵称',
  `password` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '登录密码',
  `company_name` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '公司名称',
  `phone` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '手机号',
  `email` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '用户邮箱',
  `status` smallint(6) NULL DEFAULT 0 COMMENT '0正常 1停用',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建人',
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新人',
  `user_code` bigint(20) NULL DEFAULT NULL COMMENT '用户编码，表示跟tb_merchant保持唯一',
  PRIMARY KEY (`user_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 54 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '用户表（成员表）' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_warehouse
-- ----------------------------
DROP TABLE IF EXISTS `tb_warehouse`;
CREATE TABLE `tb_warehouse`  (
  `warehouse_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '仓库ID',
  `name` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '仓库名称',
  `warehouse_status` tinyint(4) NULL DEFAULT NULL COMMENT '仓库状态',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建人',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新人',
  `farm_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '农场id',
  PRIMARY KEY (`warehouse_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 22 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '仓库表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_warehouse_dynamic
-- ----------------------------
DROP TABLE IF EXISTS `tb_warehouse_dynamic`;
CREATE TABLE `tb_warehouse_dynamic`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '出入库动态ID',
  `in_out_type` varchar(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '出入库操作类型,(O - 出库，I - 入库)',
  `info` varchar(2000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '动态信息',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `farm_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '农场ID',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 285 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '出入库动态表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_warehouse_record
-- ----------------------------
DROP TABLE IF EXISTS `tb_warehouse_record`;
CREATE TABLE `tb_warehouse_record`  (
  `in_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `in_out_type` varchar(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '出入库操作类型,(O - 出库，I - 入库)',
  `number` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '单号',
  `material_id` bigint(20) NULL DEFAULT NULL COMMENT '物品id',
  `article` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '物品名称',
  `type` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '物品类型名称 （冗余字段，目前也没用）',
  `in_out_type_id` bigint(20) NULL DEFAULT NULL COMMENT '出入库类型id',
  `method` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '出入库类型名称',
  `unit` bigint(10) NULL DEFAULT NULL COMMENT '单位id',
  `quantity` double(13, 2) NULL DEFAULT NULL COMMENT '数量',
  `operator_id` bigint(20) NULL DEFAULT NULL COMMENT '操作人userid',
  `remarks` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '备注',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建人',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新人',
  `warehouse_id` bigint(20) NULL DEFAULT NULL COMMENT '操作的仓库id',
  `farm_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '农场ID',
  PRIMARY KEY (`in_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 90 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '出入库记录表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tb_warehouse_record_type
-- ----------------------------
DROP TABLE IF EXISTS `tb_warehouse_record_type`;
CREATE TABLE `tb_warehouse_record_type`  (
  `in_out_type_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '出入库类型ID',
  `in_out_type` varchar(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '出入库操作类型,(O - 出库，I - 入库)',
  `name` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '名称',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建人',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新人',
  `farm_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '农场id,UUID',
  PRIMARY KEY (`in_out_type_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '出入库类型表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- View structure for vb_user
-- ----------------------------
DROP VIEW IF EXISTS `vb_user`;
CREATE ALGORITHM = UNDEFINED DEFINER = `root`@`%` SQL SECURITY DEFINER VIEW `vb_user` AS select `t2`.`merchant_code` AS `user_code`,`t2`.`head_url` AS `head_url`,`t2`.`nick_name` AS `nick_name`,`t2`.`phone` AS `phone`,`t2`.`email` AS `email`,`t2`.`company_name` AS `company_name`,`t2`.`account` AS `account`,`t1`.`farm_id` AS `farm_id` from (`tb_farm_merchant` `t1` join `tb_merchant` `t2` on(((`t1`.`merchant_id` = `t2`.`merchant_id`) and (`t2`.`status` = 1)))) union all select `t4`.`user_code` AS `user_code`,`t4`.`head_url` AS `head_url`,`t4`.`nick_name` AS `nick_name`,`t4`.`phone` AS `phone`,`t4`.`email` AS `email`,`t4`.`company_name` AS `company_name`,`t4`.`account` AS `account`,`t3`.`farm_id` AS `farm_id` from (`tb_farm_user` `t3` join `tb_user` `t4` on(((`t3`.`user_id` = `t4`.`user_id`) and (`t4`.`status` = 0))));

SET FOREIGN_KEY_CHECKS = 1;
